package sonata.javabean;

public class Employee {
	int eid;
	String ename;
	static double pay;
	int leaveno;
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", pay=" +pay +", leaveno=" + leaveno + ", obj=" + obj
				+ "]";
	}
	private double calsal() {
		// TODO Auto-generated method stub
		return pay;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public double getPay() {
		return pay;
	}
	public void setPay(double pay) {
		this.pay = pay;
	}
	public int getLeaveno() {
		return leaveno;
	}
	public void setLeaveno(int leaveno) {
		this.leaveno = leaveno;
	}
	public Address getObj() {
		return obj;
	}
	public void setObj(Address obj) {
		this.obj = obj;
	}
	Address obj;
}
