package sonata.javabean;

public interface calsal {
public double calsal();
public void display();
}
