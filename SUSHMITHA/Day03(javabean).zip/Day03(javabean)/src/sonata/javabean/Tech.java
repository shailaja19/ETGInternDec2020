package sonata.javabean;



public class Tech extends Employee implements calsal {
	public double calsal()
	{
		return pay+(0.012*pay);
	}
	public void display()
	{
		System.out.println("Technical Total Salary:"+calsal());
	}
	
	public static void main(String[] args) {
		Address a1=new Address();
		a1.setDoor("105a");
		a1.setStreet("kodical");
		a1.setStreet("Karnataka");
		a1.setPin(565006);
		
		
		Tech m1=new Tech();
		m1.setEid(1);
		m1.setEname("nokia");
		m1.setPay(1000);
		m1.setLeaveno(3);
		m1.setObj(a1);
		System.out.println(m1);
		m1.display();
	}

}
