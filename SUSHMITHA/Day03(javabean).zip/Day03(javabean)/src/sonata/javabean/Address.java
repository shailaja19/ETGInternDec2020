package sonata.javabean;

public class Address {
	private String door;
	
	private String street;
	private String city;
	private int pin;
	
	public String toString() {
		return "Address [door=" + door + ", street=" + street + ", city=" + city + ", pin=" + pin + "]";
	}
	public String getDoor() {
		return door;
	}
	public void setDoor(String door) {
		this.door = door;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	
}
