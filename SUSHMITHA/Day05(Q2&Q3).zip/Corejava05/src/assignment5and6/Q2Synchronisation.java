package assignment5and6;

import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Q2Synchronisation {

	public static void main(String[] args) throws IOException {
		FileInputStream fis = null;
	      FileOutputStream fos = null;
	      FileDescriptor fd = null;
	      byte[] b = {83,85,83,72,77,73,84,72,65};
	      
	      try {
	         fos = new FileOutputStream("F:/file.txt");
	         fd = fos.getFD();
	         fos.write(b);
	         fos.flush();
	         fd.sync();
	         fis = new FileInputStream("F:/file.txt");
	         int value = 0;
	          while((value = fis.read())!= -1) 
	         {
	        	 char c = (char)value;
	        	 System.out.print(c);
	            
	         }
	         
	         // print
	         System.out.print("\nsynchronisation successfully executed!!");
	         
	      } 
	      catch(Exception e)
	      {
	        
	         e.printStackTrace();
	      } 
	      finally
	      {
	    
	         if(fos!=null)
	            fos.close();
	         if(fis!=null)
	            fis.close();
	      }

	}

}
