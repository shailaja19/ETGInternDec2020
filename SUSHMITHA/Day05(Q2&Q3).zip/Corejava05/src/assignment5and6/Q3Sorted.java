package assignment5and6;

import java.util.Comparator;
import java.util.List;




class compare implements Comparator<Q3Product>
{
@Override
	public int compare(Q3Product o1, Q3Product o2) {
		return(int)(o1.getPprice()-(o2.getPprice()));
	}
	
}
public class Q3Sorted {

	public static void main(String[] args) {
		List<Q3Product> product=Q3MobileProduct.getProduct();
		
		
		 Comparator<Q3Product> comparator = Comparator.comparing( Q3Product::getPprice );
		 Q3Product maxObject = product.stream().max(comparator).get();
		 System.out.println("The product with MAX PRICE is " + maxObject);
		 System.out.println("\n");
		 
		
		product							//Ascending order
		.stream()
		.sorted((o1,o2)->(int) (o1.getPprice()-o2.getPprice()))
		.forEach(System.out::println);	//stream api 
											

		product							//Descending order
		.stream()
		.sorted((o1,o2)->(int)(o2.getPprice()-o1.getPprice()))
		.forEach(System.out::println);	//stream api
		 
		
		
	}

}
