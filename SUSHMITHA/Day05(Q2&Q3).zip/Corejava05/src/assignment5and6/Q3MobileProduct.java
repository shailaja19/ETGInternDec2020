package assignment5and6;

import java.util.ArrayList;
import java.util.List;

public class Q3MobileProduct {
	public static List<Q3Product>getProduct(){
		List<Q3Product>list=new ArrayList();
		list.add(new Q3Product(172,"NOKIA",4000));
		list.add(new Q3Product(173,"SAMSUNG",2000));
		list.add(new Q3Product(174,"IPHONE",6000));
		
		return list;

}
}
