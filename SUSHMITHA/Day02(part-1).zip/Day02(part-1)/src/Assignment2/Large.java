package Assignment2;

public class Large extends Tshirt{
	Large(){}
	Large(String color,String material,String design)
	{
		this.color=color;
		this.material=material;
		this.design=design;

	}
	
	public static void main(String[] args) {
		Large l=new Large("blue","polyster","shirt");
		l.display();

	}

}
