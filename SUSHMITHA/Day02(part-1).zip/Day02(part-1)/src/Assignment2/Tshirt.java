package Assignment2;

public class Tshirt
{
	String color;
	String material;
	String design;
	

Tshirt(){}
Tshirt(String color,String material,String design,String s)
{
	this.color=color;
	this.material=material;
	this.design=design;

}

public void display()
{
	System.out.println(color);
	System.out.println(material);
	System.out.println(design);
}
}
