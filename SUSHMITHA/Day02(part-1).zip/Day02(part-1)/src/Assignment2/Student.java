package Assignment2;

public class Student {
	int stdid;
	String stdname;
	String stdclass;
	
	Student(){}
	Student(int no,String name,String sclass)
	{
		this.stdid=no;
		this.stdname=name;
		this.stdclass=sclass;
	}
	public void display()
	{
		System.out.println(stdid);
		System.out.println(stdname);
		System.out.println(stdclass);
	}
}