package Assignment2;

public class Studentdata {

	public static void main(String[] args) {
		Student s=new Student();
		s.stdid=1;
		s.stdname="SUSHMITHA";
		s.stdclass="first";
		s.display();
		
		Student s1=new Student(2,"PRERANA","second");
		s1.display();
		}

}
