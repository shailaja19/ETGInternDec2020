package Assignment2;

public class Productdetails {

	public static void main(String[] args) {
		Product p1=new Product(1,"SOAP",123);
		p1.display();
		
		Product p=new Product(2,"pencil",12);
		p.display();
		
	}

}
