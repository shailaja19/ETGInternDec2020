package Assignment2;

public class Product 
{
	int proid;
	String proname;
	double proprize;
	
	Product(){}
	Product(int no,String name,double prize)
	{
		this.proid=no;
		this.proname=name;
		this.proprize=prize;
	}

	public void display()
	{
		System.out.println(proid);
		System.out.println(proname);
		System.out.println(proprize+100);
	}


}
