
package Assignment2;
public class Small extends Tshirt 

{
		Small(){}
		Small(String color,String material,String design)
		{
			this.color=color;
			this.material=material;
			this.design=design;

		}
		
		public static void main(String[] args) {
		Small s=new Small("blue","polyster","shirt");
		s.display();
		}

}
