package Assignment2;

public class XtraLarge extends Tshirt{
	XtraLarge(){}
	XtraLarge(String color,String material,String design)
	{
		this.color=color;
		this.material=material;
		this.design=design;

	}
	
	public static void main(String[] args) {
		XtraLarge x=new XtraLarge("blue","polyster","shirt");
		x.display();

	}

}
