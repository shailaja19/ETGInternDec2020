package corejava3;

public class Q2Testclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Q2Rectangle r=new Q2Rectangle(2,4);
		System.out.println(r.area());
		
		Q2Square r1=new Q2Square(4);
		System.out.println(r1.area());
		
		Q2Triangle r2=new Q2Triangle(4,3);
		System.out.println(r2.area());
	}

}
