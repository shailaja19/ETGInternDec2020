package corejava3;

public class Q2Rectangle implements Q2Shape{

private double len;

private double width;
Q2Rectangle(){}
Q2Rectangle(double len,double width)
{
	this.len=len;
	//this.height=height;
	this.width=width;
}
public double area() 
{
	return len*width;
}
	

}
