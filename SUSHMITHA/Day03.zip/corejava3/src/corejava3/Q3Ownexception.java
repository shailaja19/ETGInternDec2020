package corejava3;

public class Q3Ownexception extends Exception{
	Q3Ownexception(String s)
	{
		super(s);
	}
}


