package corejava3;

public class Q3Employee {
	int empId;
	String empName;
	double empSal; 
	
	Q3Employee(){}
	Q3Employee(int a,String b,double c)
	{
		this.empId=a;
		this.empName=b;
		this.empSal=c;
	}
	
	public double salCal()
	{
		return(empSal*12);
	} 
	public void display()
	{
		System.out.println(empId);
		System.out.println(empName);
		System.out.println(empSal);
	} 
	public static void main(String[] args) throws Q3Ownexception{
		// TODO Auto-generated method stub
		Q3Employee c=new Q3Employee(1,"sush",30000);
		double i=c.salCal();
		if(i<100000)
		{
			throw new Q3Ownexception("less than 1lakh");
		}
		else
			c.display();
	}

}
