package corejava3;

public class Q5UsingPeople {
	String name;
	String work;
	String day;
	
	Q5UsingPeople(){}
	Q5UsingPeople(String na,String w,String d)
	{
		this.name=na;
		this.work=w;
		this.day=d;
	}
	public void display()
	{
		System.out.println(name+" has to " +work+" on " +day);
	}
	
	public static void main(String[] args) {
		Q5UsingPeople q=new Q5UsingPeople();
		q.name="sush";
		q.work="pump water";
		q.day="Sundsy";
		q.display();
		
		Q5UsingPeople q1=new Q5UsingPeople("sushmitha","water garden","monday");
		q1.display();
		
		
	}

}
