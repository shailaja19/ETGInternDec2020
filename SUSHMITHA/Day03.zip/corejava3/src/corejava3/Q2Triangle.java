package corejava3;

public class Q2Triangle {

	private double len;
	private double height;
	private double width;
	Q2Triangle(){}
	Q2Triangle(double len,double height)
	{
		this.len=len;
		this.height=height;
		//this.width=width;
	}
	public double area() 
	{
		return 0.5*len*height;
	}
		
}
