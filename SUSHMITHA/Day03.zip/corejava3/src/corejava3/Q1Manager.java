package corejava3;

public class Q1Manager extends Q1Employee {
Q1Manager(){}
Q1Manager(int a,String b,double c)
{
	super(a,b,c);
}
public void salCal()
{
	System.out.println("Manager Salary"+empSal);
} 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Q1Manager m=new Q1Manager(1,"sush",123);
		m.display();
		m.salCal();
		
	}

}
