package corejava3;

public class Q1Employee 
{
	int empId;
	String empName;
	double empSal; 
	
	Q1Employee(){}
	Q1Employee(int a,String b,double c)
	{
		this.empId=a;
		this.empName=b;
		this.empSal=c;
	}
	
	public void salCal()
	{
		System.out.println("emp Salary"+empSal);
	} 
	public void display()
	{
		System.out.println(empId);
		System.out.println(empName);
		System.out.println(salCal());
	} 
}
