package corejava3;

public class Q1Developer extends Q1Employee {

	Q1Developer(){}
	Q1Developer(int a,String b,double c)
	{
		super(a,b,c);
	}
	public void salCal()
	{
		
		System.out.println("Developer Salary");
	} 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Q1Developer d=new Q1Developer(1,"sushmitha",1234);
			d.display();
			d.salCal();
			
		}

}
