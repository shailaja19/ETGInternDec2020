package corejava3;

public class Q1Tester extends Q1Employee {
	Q1Tester(){}
	Q1Tester(int a,String b,double c)
	{
		super(a,b,c);
	}
	public void salCal()
	{
	
		System.out.println("tester Salary");
	} 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Q1Tester t=new Q1Tester(1,"sushma",1253);
			t.display();
			t.salCal();
			
		}
}
