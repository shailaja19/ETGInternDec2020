package corejava3;

public interface Q2Shape {
	
	public double area();
	
}