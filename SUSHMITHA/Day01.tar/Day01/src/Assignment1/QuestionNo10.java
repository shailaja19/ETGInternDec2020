package Assignment1;

public class QuestionNo10 {

	public static void main(String[] args) {
		int n = 0,largest1 = 0, largest2 = 0, temp = 0;
		int array[]= {1,2,3,4,5};
	 
	    largest1 = array[0];
	    largest2 = array[1];
	 
	    if (largest1 < largest2)
	    {
	    	{
	            temp = largest1;
	            largest1 = largest2;
	            largest2 = temp;
	        }
	     
	        for (int i = 2; i < array.length; i++)
	        {
	            if (array[i] > largest1)
	            {
	                largest2 = largest1;
	                largest1 = array[i];
	            }
	            else if (array[i] > largest2 && array[i] != largest1)
	            {
	                largest2 = array[i];
	            }
	        }
	     
	        System.out.println("The FIRST LARGEST :"+largest1);
	        System.out.print ("THE SECOND LARGEST :"+largest2);
	    }
	    
	}
}


