package Assignment1;

import java.util.Scanner;



public class QuestionNo1 {
	public static void main(String[] args) {
		
		int x=10 ,y=20 ,z=30 ;
		Scanner s=new Scanner(System.in);
		if(x>y && x>z)
		{
		 System.out.println("largest no is:"+x);
		}
		else if(y>x && y>z)
		{
		  System.out.println("largest no is:"+y);
		}
		else
		{
		System.out.println("largest no is:"+z);
		}

	}
}

