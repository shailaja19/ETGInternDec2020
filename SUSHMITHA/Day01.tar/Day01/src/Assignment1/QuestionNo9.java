package Assignment1;

public class QuestionNo9 {
	public static void main(String[] args) {
		int arr[] = {1, 2, 3, 4, 2, 7, 8, 8, 3, 3},element=0,i,maxcount=0;   
	    
	    for(i = 0; i < arr.length; i++)
	    { 
	    	int count=1;
	        for(int j = i + 1; j <arr.length; j++) 
	        {  
	            if(arr[i] == arr[j])  
	            {
	            	count++;
	            }
	        }
	        
	        
	        if(count>maxcount)
	        {
	            	maxcount=count;
	            	element=arr[i];
	            	
	        }
	    }
	    
	    System.out.println(element+" is repeated maximum no of time");
	}
}
