package Assignment1;

public class QuestionNo6 {
	    public static void main(String[] args) 
	    { 
	        int [] array = {'1','2','3','4','5'}; 
	           System.out.println("Original array: "); 
	        for (int k = 0; k <array.length; k++)
	        { 
	             System.out.print(array[k] + " "); 
	        }
	    System.out.println();
	    System.out.println("Reversed array: "); 
	    for (int i = 4; i >=0; i--) 
	    { 
	    	 System.out.print(array[i] + " "); 
	    }  
	}
}