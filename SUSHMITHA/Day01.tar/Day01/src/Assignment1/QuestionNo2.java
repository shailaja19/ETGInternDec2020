package Assignment1;

public class QuestionNo2 {

	public static void main(String[] args) {
		int n=10,i;
		System.out.println("The first ten natural numbers are:");
		for(i=1;i<=n;i++)
		{
			System.out.println(i);
		}
	}

}
