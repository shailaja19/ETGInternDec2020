package Assignment1;
import java.util.Scanner;
public class QuestionNo4 {

	public static void main(String[] args) {
		int sum=0;
		Scanner sc=new Scanner(System.in);
		int a[]=new int[5];
		System.out.println("enter the val into array");

		for(int i=0;i<5;i++)
		{
			a[i]=sc.nextInt();
		        sum=sum+a[i];

		}
		
		System.out.println("Sum of array is:"+sum);

	}

}
