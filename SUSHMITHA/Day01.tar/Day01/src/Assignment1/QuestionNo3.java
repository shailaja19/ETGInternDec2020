package Assignment1;

public class QuestionNo3 {

	public static void main(String[] args) {
		int n=10;
		System.out.println("Cube of "+n+" is: "+n*n*n);
	}

}
