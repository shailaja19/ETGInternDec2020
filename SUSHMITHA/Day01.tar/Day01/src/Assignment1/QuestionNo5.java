package Assignment1;

import java.util.Scanner;

public class QuestionNo5 {

	public static void main(String[] args) {
		int num[] = {1, 2, 3, 4, 5},p=0;
        int toFind = 2;
        

        for (int n=0;n<5;n++) {
            if (n == toFind)
            {
            	p++;
            }
        }

        if(p==1)
            System.out.println(toFind + " is found");
        else
            System.out.println(toFind + " is not found");
    
	}

}
