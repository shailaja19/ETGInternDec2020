package Assignment1;

public class QuestionNo7 {

	public static void main(String[] args) {
		char ch[]= {'s','u','s','h','m','i','t','h','a'};
		System.out.println("String is: ");
		for(int i=0;i<ch.length;i++)
		{
			System.out.print(ch[i]);
		}
		System.out.println();
		for(int i=0;i<ch.length;i++)
		{
			if(ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||ch[i]=='o'||ch[i]=='u')
			{
				ch[i]='$';
			}
		}
		System.out.println("String after replacing vowels with special charater:");
		for(int i=0;i<ch.length;i++)
		{
			System.out.print(ch[i]);
		}
	}
		

}


