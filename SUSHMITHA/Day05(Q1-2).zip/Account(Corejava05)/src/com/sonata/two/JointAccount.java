package com.sonata.two;

import com.sonata.one.Operation;

public class JointAccount {

	public static void main(String[] args) {
		Operation c=new Operation(3,"SUSHMA",12000);
		
		c.details();
		System.out.println("Total balance after amount deposited is:"+c.deposit(15000));
		System.out.println("withdrawed amount is:"+c.withDraw(5000));
	}

}
