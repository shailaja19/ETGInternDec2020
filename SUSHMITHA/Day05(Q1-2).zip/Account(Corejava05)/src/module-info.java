module Account {
	requires Bank;
}