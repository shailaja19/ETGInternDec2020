package assignment4;

import java.util.ArrayList;
//import java.util.Collections;



public class Q2CompareTo {

	public static void main(String[] args) {
		
		ArrayList<Q2Student> n1=new ArrayList<>();
		n1.add(new Q2Student(105,"sushmitha",35));
		n1.add(new Q2Student(106,"prerna",65));
		n1.add(new Q2Student(107,"sushma",18));
		
		n1.sort((Q2Student s1, Q2Student s2)->s2.marks-s1.marks); 
		n1.forEach((s)->System.out.println(s.stdid+" "+s.stdname+" "+s.marks)); 
		
		
	}

}
