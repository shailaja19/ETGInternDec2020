package assignment4;

public interface Q1EmployeeInt {
		public void addEmployee(Q1Employee e);
		public void deleteEmployee(Q1Employee e);
		public double yearSalary(double sal);
		public double appSalary(Q1Employee e1);
		

}
