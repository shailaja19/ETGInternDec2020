package assignment4;

public class Q1Employee extends Q1EmployeeImpl {
	int empid;
	String empname;
	double sal;
	Q1Employee(int a , String b , double c){
		 this.empid=a;
		 this.empname=b;
		 this.sal=c;
	 }
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", sal=" + sal + "]";
	}
}
