package assignment4;

import java.util.ArrayList;
import java.util.List;



public class Q2Data {

	public static List<Q2Student>getStudent(){
		List<Q2Student>list=new ArrayList();
		list.add(new Q2Student(172,"soap",400));
		list.add(new Q2Student(173,"bucket",500));
		list.add(new Q2Student(174,"art",600));
		
		return list;

}
}