package assignment4;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Q1UseEmployee {

	public static void main(String[] args) {
		List<Q1Employee> p1 = new LinkedList<Q1Employee>();
		p1.add(new Q1Employee( 121 , "sushmitha" , 35000));
		p1.add(new Q1Employee( 122 , "sush" , 3000));
		p1.add(new Q1Employee( 123 , "prerna" , 8000));
		
		for(Q1Employee p2:p1) {
			
        	System.out.println(p2.empid + " The employee"+ p2.empname + " salary is "+ p2.sal+"yearly salary"+ p2.yearSalary(p2.sal));
			
        }
      
        for(Q1Employee p2:p1) {
        	if(p2.sal<10000) {
        		 double sal=p2.sal;
        		 double sal1=sal+5000;
        		System.out.println("The increased salary " + sal1);
        	}
        }
        
		
	}		

}
