package assignment4;

public class Q2Student implements Comparable<Q2Student>{
	int stdid;
	String stdname;
	int marks;
	
public Q2Student(int i,String s,int a)
{
	this.stdid=i;
	this.stdname=s;
	this.marks=a;
}

public int compareTo(Q2Student st)
{
	if(marks==st.marks)
		return 0;
	else if(marks>st.marks)
		return 1;
	else
		return -1;
}

}
