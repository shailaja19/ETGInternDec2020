package assignment4;

import java.util.LinkedList;
import java.util.List;

public class Q1EmployeeImpl implements Q1EmployeeInt {
	List<Q1Employee> l1=new LinkedList<>();
	
	@Override
	public void addEmployee(Q1Employee e) 
	{
		//System.out.println(e);
		return;
	}
	

	@Override
	public void deleteEmployee(Q1Employee e) {
		// TODO Auto-generated method stub
		l1.remove(e);
		
	}

	@Override
	public double yearSalary(double sal) {
		
		return sal*12;
	}

	@Override
	public double appSalary(Q1Employee e1) {
		return 0;
	}

		
		
		
		
		
	}



