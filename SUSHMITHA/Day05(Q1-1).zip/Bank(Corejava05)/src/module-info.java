module Bank {
	exports com.sonata.one;
}