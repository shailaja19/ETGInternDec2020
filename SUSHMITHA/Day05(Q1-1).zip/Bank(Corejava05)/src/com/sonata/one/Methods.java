package com.sonata.one;

public interface Methods {
	public double deposit (double amount);
	public double withDraw (double amount);

}
