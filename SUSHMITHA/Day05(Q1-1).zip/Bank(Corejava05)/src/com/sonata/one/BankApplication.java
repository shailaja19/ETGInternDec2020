package com.sonata.one;

public class BankApplication {

		int accNo;
		String accName;
		double accBalance;
		
		BankApplication() {}
		BankApplication(int no,String name,double accBalance)
		{
			this.accNo=no;
			this.accName=name;
			this.accBalance=accBalance;
		}
		public void details()
		{
			System.out.println(accNo);
	    	System.out.println(accName);
	    	
	 
		}
}


