package com.sonata.one;

public class Operation extends BankApplication implements Methods {

	
		Operation(){}
		public Operation(int h,String n,double c)
		{
			super(h,n,c);
			
		}
		public double deposit (double amount)
		{
			return accBalance+amount;
			
		}
		public double withDraw (double amount)
		{
			
			return amount;
		}

}


