package MyOwnAutoShopProject;

public class Car {
		int speed;
		double regularPrice;
		String color;
		
		Car(){}
		Car(int h,double n,String c)
		{
			
				this.speed=h;
				this.regularPrice=n;
				this.color=c;
			
		}
		
		
		double getSalePrice()
		{
			return regularPrice;
			
		}
		public void details()
		{
			System.out.println("speed:"+speed);
			System.out.println(getSalePrice());
			System.out.println("color:"+color);
		}


}
