package MyOwnAutoShopProject;

public class Ford extends Car {

	
			int year;
			int manufactureDiscount;
			Ford(){}
			Ford(int h,double n,String c)
			{
				super(h,n,c);
				
			}
			double getSalePrice()
			{
				return regularPrice-manufactureDiscount;
			}
			
			public static void main(String[] args) {
			Ford f=new Ford(200,3000,"red");
			f.year=2010;
			f.manufactureDiscount=200;
			f.details();
	}

}
