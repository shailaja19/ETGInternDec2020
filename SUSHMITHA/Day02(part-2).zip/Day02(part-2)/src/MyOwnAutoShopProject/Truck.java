package MyOwnAutoShopProject;

public class Truck extends Car {
	int weight;
	Truck(){}
	Truck(int h,double n,String c)
	{
		super(h,n,c);
		
	}
	double getSalePrice()
	{
		if(weight>2000)
		{
			return regularPrice-(regularPrice*0.010);
		}
		else
		{
			return regularPrice=regularPrice-(regularPrice*0.020);
		}
		
	}
	public static void main(String[] args) {
		Truck t=new Truck(1,276,"orange");
		t.weight=1900;
		t.details();
		

	}

}
