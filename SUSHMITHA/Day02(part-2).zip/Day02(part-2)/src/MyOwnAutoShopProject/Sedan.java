package MyOwnAutoShopProject;

public class Sedan extends Car{
	int length;
	Sedan(){}
	Sedan(int h,double n,String c)
	{
		super(h,n,c);
		
	}
	double getSalePrice()
	{
		if(length>20)
		{
			return regularPrice-(regularPrice*0.05);
		}
		else
		{
			return regularPrice=regularPrice-(regularPrice*0.010);
		}
		
	}
	public static void main(String[] args) {
		Sedan t=new Sedan(1,276,"orange");
		t.length=12;
		t.details();
		
		

	}

}
