package MyOwnAutoShopProject;

public class Price extends Car  {
	Price(){}
	Price(int h,double n,String c)
	{
		super(h,n,c);
		
	}
	public void details()
	{
		System.out.println(regularPrice);
	}
	

	public static void main(String[] args) {
		

		Price f=new Price(100,3000,"red");
		f.details();
		
		Price f1=new Price(100,4000,"orange");
		f1.details();
		
		Price f2=new Price(100,5000,"white");
		f2.details();
		
		
	}

}
