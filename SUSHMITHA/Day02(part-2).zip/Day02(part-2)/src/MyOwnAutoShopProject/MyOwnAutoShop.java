package MyOwnAutoShopProject;

public class MyOwnAutoShop extends Car {

	/*public void details()
	{
		super.details();
		
	}*/
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sedan s=new Sedan(234,2000,"red");
		s.details();
		
		Ford s1=new Ford(214,4000,"orange");
		s1.details();
		
		Ford s2=new Ford(228,3000,"green");
		s2.details();
		
		Car c=new Car(213,3000,"white");
		c.details();
		
	}

}
