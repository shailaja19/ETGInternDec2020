package com.sonata.assignmentday5;

public class Bank implements Bankinterface {
	int accid;
	String accname;
	double deposite;
	double withdraw;
	
	public Bank () {}
	public Bank( int accid , String accname,double deposite , double withdraw) {
		this.accid=accid;
		this.accname=accname;
		this.deposite=deposite;
		this.withdraw=withdraw;
	}

		@Override
		public double withdraw(double amount) {
			return 0;
		}
		@Override
		public double deposite(double amount) {
			return 0;
		}

		public double totalbalance(double amount1, double amount2) {
		   return 0;
		}
		public void display() {
			System.out.println("Account ID" +accid);
			System.out.println("Name of Account holder "+accname);
			System.out.println("Withdrawn amount  "+withdraw(withdraw));
			System.out.println("Totalbalance" +totalbalance(deposite,withdraw));
		}



}
