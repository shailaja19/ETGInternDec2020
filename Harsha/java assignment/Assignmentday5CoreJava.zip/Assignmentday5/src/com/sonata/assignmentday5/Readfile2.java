package com.sonata.assignmentday5;

public class Readfile2 extends Thread{
	Readfile1 line; 
	  
    Readfile2(Readfile1 line) 
    { 
        this.line = line; 
    } 

    @Override
    public void run() 
    { 
        line.read(); 
    } 
}
