package com.sonata.assignmentday5;

import java.util.ArrayList;
import java.util.List;

public class Dataproduct {

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static List<Product> getproduct(){
		 List<Product> p=new ArrayList();
		 p.add(new Product( 10 , "Iqoo",30000));
		 p.add(new Product( 10 , "Oppo",19000));
		 p.add(new Product( 10 , "MI",12000));
		 p.add(new Product( 10 , "Vivo",20000));
		 p.add(new Product( 20 , "Air conditioner",3300));
		 p.add(new Product( 30 , "Diwan",25000));
		 p.add(new Product( 40 , "Cooler",10000));
		 p.add(new Product( 50 , "Washing machine",45000));
		 p.add(new Product( 60 , "Exhaust",3000));
		 p.add(new Product( 70 , "Chimney",25000));
		 p.add(new Product( 80, "Keyboard",750));
		 p.add(new Product( 70 , "Fan",3500));
		 return p;
}
}
