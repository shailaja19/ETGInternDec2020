package com.sonata.assignmentday5;

public class Currentacc extends Bank implements Bankinterface{
	Currentacc(){}
	 public Currentacc( int a , String b,double c, double d) {
			super(a,b,c,d);
			}
			 @Override
			 public double withdraw(double amount) {
			 	return amount;
			 }
			 @Override
			 public double deposite(double amount) {
			 	return amount;
			 }
			
			 public double totalbalance(double amount1, double amount2) {
			 	return  amount1-amount2;
			 }
			
			
		

	public static void main(String[] args) {
			
				Currentacc c1 = new Currentacc(31 , "Harsha" , 43100,33000);
				Currentacc c2 = new Currentacc(26 , "Jyothi" , 45700,23000);

				c1.display();
				c2.display();
				
		 
	}

}
