package com.sonata.assignmentday5;

public class Jointacc extends Bank implements Bankinterface {
	Jointacc(){}
	 public Jointacc( int a , String b,double c, double d) {
			super(a,b,c,d);
		}
	 
	 @Override
	 public double withdraw(double amount) {
	 	return amount;
	 }
	 @Override
	 public double deposite(double amount) {
	 	return amount;
	 }
	
	 public double totalbalance(double amount1, double amount2) {
	 	return  amount1-amount2;
	 }

	public static void main(String[] args) {
		Jointacc j1 = new Jointacc(31 , "Harsha" , 43100,33000);
		Jointacc j2 = new Jointacc(26 , "Jyothi" , 45700,23000);

		j1.display();
		j2.display();

	}

}
