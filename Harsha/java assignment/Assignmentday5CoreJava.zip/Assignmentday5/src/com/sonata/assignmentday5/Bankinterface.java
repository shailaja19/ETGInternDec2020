package com.sonata.assignmentday5;

public interface Bankinterface {
	public double withdraw(double amount1);
	public double deposite(double amount2);
}
