package com.sonata.assignmentday5;

public class Savingsacc extends Bank implements Bankinterface {

	Savingsacc(){}
	 public Savingsacc( int a , String b,double c, double d) {
			super(a,b,c,d);
		}
	 
	 @Override
	 public double withdraw(double amount) {
	 	return amount;
	 }
	 @Override
	 public double deposite(double amount) {
	 	return amount;
	 }
	
	 public double totalbalance(double amount1, double amount2) {
	 	return  amount1-amount2;
	 }
	public static void main(String[] args) {
		Savingsacc s1 = new Savingsacc(31 , "Harsha" , 43100,33000);
		s1.display();

	}

}
