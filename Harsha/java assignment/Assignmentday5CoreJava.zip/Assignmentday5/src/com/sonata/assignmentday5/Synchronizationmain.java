package com.sonata.assignmentday5;

public class Synchronizationmain {

	public static void main(String[] args) {
		Readfile1 obj = new Readfile1();
		Readfile2 s1= new Readfile2(obj);
		Readfile2 s2= new Readfile2(obj);
		s1.start();
		s2.start();
	}

}
