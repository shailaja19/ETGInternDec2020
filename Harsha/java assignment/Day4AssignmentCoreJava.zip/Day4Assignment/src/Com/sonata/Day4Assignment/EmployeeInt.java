package Com.sonata.Day4Assignment;
import java.util.List;


public interface EmployeeInt {

	public void addemployee(Employee o);
	public void removeemployee(Employee o);
	public double yearsalary(double salary);
	public double appsalary(Employee o);
	public void display(Employee e);
}
