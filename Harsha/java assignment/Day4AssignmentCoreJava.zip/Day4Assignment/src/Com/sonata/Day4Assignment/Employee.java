package Com.sonata.Day4Assignment;

public class Employee {
	int empid;
	String empname;
	double empsal;
	Employee(int empid, String empname, int j){}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public double getEmpsal() {
		return empsal;
	}
	public void setEmpsal(double empsal) {
		this.empsal = empsal;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname + ", empsal=" + empsal + "]";
	}
	public String yearsalary(double empsal2) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
