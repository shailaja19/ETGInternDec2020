package Com.sonata.Day4Assignment;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;



public class EmployeeImpl implements EmployeeInt {
	List<Employee> l1=new LinkedList<>();
	@Override
	public void addemployee(Employee o) {
		l1.add(o);
		
	}

	@Override
	public void removeemployee(Employee o) {
		l1.remove(o);
		
	}

	@Override
	public double yearsalary(double salary) {
		
		return 0;
	}

	@Override
	public double appsalary(Employee o) {
		
		return 0;
	}

	
	public Iterator<EmployeeImpl> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void display(Employee e) {
		// TODO Auto-generated method stub
		
	}

}
