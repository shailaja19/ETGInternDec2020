package Com.sonata.Day4Assignment;

import java.util.ArrayList;
import java.util.List;
public class Studentdata {
	public static List<Student>getStudent(){
		 
		List<Student> s=new ArrayList();
		 s.add(new Student( 431, "Harsha",88));
		 s.add(new Student( 457 , "Jyothi",89));
		 s.add(new Student( 448 , "Dinesh",76));
		 s.add(new Student( 449 , "Yeshwanth",94));
		 s.add(new Student( 157 , "Nisargha",93));
		 s.add(new Student( 859 , "Nandini",82));
		 s.add(new Student( 858 , "Maithri",83));
		 return s;
	}
}
