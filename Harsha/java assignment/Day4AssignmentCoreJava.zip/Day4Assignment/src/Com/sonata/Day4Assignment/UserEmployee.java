package Com.sonata.Day4Assignment;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class UserEmployee {

	public static void main(String[] args) {
		 List<Employee> p1 = new LinkedList<Employee>();
			p1.add(new Employee( 431 , "Harsha" , 35000));
			p1.add(new Employee(457 , "Jyothi",89000));
			p1.add(new Employee( 448 , "Dinesh",76000));
			
			for(Employee p2:p1) {
	        	System.out.println("The employee id is " + p2.empid + " The employee  name is "+ p2.empname + " The employee  salary is "+ p2.empsal);
	        };
	        for(Employee p2:p1) {
	        	System.out.println( " Yearly salary "+ p2.yearsalary(p2.empsal));
	        };
	        for(Employee p2:p1) {
	        	if(p2.empsal<10000) {
	        		 double sal=p2.empsal;
	        		 double sal1=sal+5000;
	        		System.out.println("Increased Salary " + sal1);
	        	}
	        }
	}
}
