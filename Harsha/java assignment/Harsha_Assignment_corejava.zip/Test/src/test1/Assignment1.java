package test1;

public class Assignment1 {

	public static void main(String[] args) {
		int a=12,b=25,c=89;
		if(a>b&&a>c)
		{
		System.out.println(a);
		}
		if(b>a&&b>c)
		{
		System.out.println(b);
		}
		if(c>a&&c>b)
		{
		System.out.println(c);
		}
	}

}
