package test1;

public class Assignment3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=2,cube;
		cube=a*a*a;
		System.out.println(cube);

	}

}
