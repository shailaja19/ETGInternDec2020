package test1;

public class Assignment6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a={1,2,3,4,5};
		int[] b=new int[5];
		int j;
		j=b.length;
		for(int i=0;i<a.length;i++)
		{
		b[j-1]=a[i];
		j=j-1;
		}
		for(j=0;j<a.length;j++)
		{
			System.out.println(b[j]);
		}
	}

}
