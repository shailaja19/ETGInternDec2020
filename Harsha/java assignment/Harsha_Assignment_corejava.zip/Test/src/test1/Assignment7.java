package test1;

public class Assignment7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] st={'h','e','l','l','o'};
		
		for(int i=0;i<5;i++)
		{
		if(st[i]=='a'||st[i]=='e'||st[i]=='i'||st[i]=='o'||st[i]=='u')
		{
		st[i]='$';
		}
		System.out.println(st[i]);
		}
	}

}
