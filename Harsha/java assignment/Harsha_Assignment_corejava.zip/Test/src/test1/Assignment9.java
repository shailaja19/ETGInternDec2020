package test1;

public class Assignment9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

int[] a={1,2,3,4,2,3,4,5,6,4};
int i,j,dcount=0,mcount=0;
for(i=0;i<a.length;i++)
{
dcount=0;
for(j=0;j<a.length;j++)
{
if(a[i]==a[j])
{
dcount=dcount+1;
}
}
if(dcount>mcount)
{
mcount=dcount;
}
}
System.out.println(mcount);
	}

}
