package ad2;

public class Student {
int stdid;
String stdname;
int stdclass;
Student(){}
public void display()
{
	System.out.println(stdid);
	System.out.println(stdname);
	System.out.println(stdclass);
}
public static void main(String[] args) {
		Student s1=new Student();
		s1.stdid=431;
		s1.stdname="harsha";
		s1.stdclass=10;
		s1.display();
	}

}
