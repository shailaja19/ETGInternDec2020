package ad2;

public class Product {
	int proid;
	String proname;
	double proprice;
	Product(){}
	public void display() 
	{
		System.out.println(proid);
		System.out.println(proname);
		System.out.println(proprice);
	}
	public double gst()
	{
		proprice=(proprice+proprice*0.28);
		return proprice;
	}
	public static void main(String[] args) {
		Product p1=new Product();
		p1.proid=4534;
		p1.proname="laptop";
		p1.proprice=40000;
		p1.gst();
		p1.display();

	}

}
