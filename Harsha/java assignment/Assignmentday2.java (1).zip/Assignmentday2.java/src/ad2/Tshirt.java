package ad2;

public class Tshirt {
	String color="blue";
	String material="spandex";
	String design="henley";
	static String size="small";
	public void display()
	{
		System.out.println(color);
		System.out.println(material);
		System.out.println(design);
	}
	

	public static void main(String[] args) {
		Tshirt t1=new Tshirt();
		System.out.println(size);
		t1.display();
		size="large";
		System.out.println(size);
		Tshirt t2=new Tshirt();
		t2.display();
		size="xtra large";
		System.out.println(size);
		Tshirt t3=new Tshirt();
		t3.display();
	}

}
