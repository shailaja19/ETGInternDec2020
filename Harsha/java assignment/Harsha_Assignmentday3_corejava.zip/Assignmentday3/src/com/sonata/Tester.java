package com.sonata;

public class Tester {
	

	Tester(){}
	Tester(int empid,String empname,int empsal){
		
	}
	public void salcal()
	{
		System.out.println("Tester salary");
	}

	public static void main(String[] args) {
		Tester t1=new Tester(124,"ff",4000);
		t1.salcal();
		

	}

}
