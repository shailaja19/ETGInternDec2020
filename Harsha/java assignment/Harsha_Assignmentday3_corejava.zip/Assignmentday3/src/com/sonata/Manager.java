package com.sonata;

public class Manager extends Employee{
	Manager(){}
	Manager(int empid,String empname,int empsal){}
	public void salcal()
	{
		System.out.println("manager salary");
	}

	public static void main(String[] args) {
		Manager m1=new Manager(123,"harsha",5000);
		m1.salcal();
	
		

	}

}
