package com.sonata;

public class Using1 extends Staff{

	Using1(){}

	public static void main(String[] args) {
		Using1 u1=new Using1();
		u1.setBpay(1000);
		u1.setEid(10);
		u1.setEname("hee");
		u1.setNol(5);
		u1.calsal();
		System.out.println(u1);
	}


}
