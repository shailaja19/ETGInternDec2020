package com.sonata;

public class Myexception extends Exception{
	Myexception(String s)
	{
		super(s);	}

}
