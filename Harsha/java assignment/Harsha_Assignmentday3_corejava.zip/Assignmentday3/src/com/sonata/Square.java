package com.sonata;

public class Square extends Shape{
	int len;
	Square(int a){
		this.len=a;
	}
	public void area()
	{
		System.out.println("Square area");
		System.out.println(len*len);
	}


	public static void main(String[] args) {
		Square s1=new Square(5);
		s1.area();

	}

}
