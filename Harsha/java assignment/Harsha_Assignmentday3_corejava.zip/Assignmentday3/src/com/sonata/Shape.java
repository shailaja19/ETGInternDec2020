package com.sonata;

public class Shape {
	int length;
	int height;
	int width;
	Shape(){}
	Shape(int length,int height,int width){}
	public void area()
	{
		System.out.println("main class");
	}

}
