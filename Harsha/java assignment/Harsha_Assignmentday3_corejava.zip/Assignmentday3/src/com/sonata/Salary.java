package com.sonata;

public class Salary {
	static int sal=20000;

	public static void main(String[] args) throws Myexception{
		
		if(sal<100000)
		{
			throw new Myexception("salary is less");
		}
		else
		{
			System.out.println(sal);
		}

	}

}
