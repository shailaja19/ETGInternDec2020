package com.sonata;

public class Employee {
int empid=22;
String empname="hi";
 int empsal=1000;
Employee(){}
Employee(int empid,String empname,int empsal){}
public void salcal()
{
	System.out.println("employee salary");
}
public void display()
{
	System.out.println(empsal);
}
}
