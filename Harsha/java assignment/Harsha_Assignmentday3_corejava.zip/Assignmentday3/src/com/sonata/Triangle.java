package com.sonata;

public class Triangle extends Shape{
	int len,hei;
	Triangle(int a,int b)
	{
		this.len=a;
		this.hei=b;
	}
	public void area()
	{
		System.out.println("triangle area");
		System.out.println((len*hei)/2);
	}


	public static void main(String[] args) {
		Triangle t1=new Triangle(5,2);
		t1.area();

	}

}
