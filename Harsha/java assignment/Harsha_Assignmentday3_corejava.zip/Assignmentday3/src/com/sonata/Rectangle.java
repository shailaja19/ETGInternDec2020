package com.sonata;

public class Rectangle extends Shape{
	int len;
	int bre;
	Rectangle(int le,int br){
	this.len=le;
	this.bre=br;
	}
	
	public void area()
	{
		System.out.println("rectangle area");
		System.out.println(len*bre);
	}

	public static void main(String[] args) {
		Rectangle r1=new Rectangle(10,4);
		r1.area();
	}

}
