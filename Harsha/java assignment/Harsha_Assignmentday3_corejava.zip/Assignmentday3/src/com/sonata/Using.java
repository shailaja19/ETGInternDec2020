package com.sonata;

public class Using extends TechEmp{
	Using(){}

	public static void main(String[] args) {
		Using u1=new Using();
		u1.setBpay(1000);
		u1.setEid(10);
		u1.setEname("hee");
		u1.setNol(5);
		u1.calsal();
		System.out.println(u1);
	}

}
