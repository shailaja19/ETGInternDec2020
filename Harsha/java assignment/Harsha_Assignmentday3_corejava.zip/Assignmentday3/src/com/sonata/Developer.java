package com.sonata;

public class Developer extends Employee {
	Developer(){}
	Developer(int empid,String empname,int empsal){}
	public void salcal()
	{
		System.out.println("developer salary");
	}

	public static void main(String[] args) {
		Developer d1=new Developer(23,"ss",4000);
		d1.salcal();

	}

}
