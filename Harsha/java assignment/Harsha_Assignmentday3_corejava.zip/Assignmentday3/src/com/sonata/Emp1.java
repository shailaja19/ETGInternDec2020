package com.sonata;

public class Emp1 {
int empid;
String empname;
Address obj;
int basicpay;
int noofleaves;
public int calsal()
{
	System.out.println("employee salary");
	return 0;
}
public void display()
{
	System.out.println("hi");
}
}
