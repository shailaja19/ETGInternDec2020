package com.sonata;

public class TechEmp extends Emp1{
	int eid;
	String ename;
	Address obj;
	int bpay;
	int nol;
	TechEmp(){}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public Address getObj() {
		return obj;
	}
	public void setObj(Address obj) {
		this.obj = obj;
	}
	public int getBpay() {
		return bpay;
	}
	public void setBpay(int bpay) {
		this.bpay = bpay;
	}
	public int getNol() {
		return nol;
	}
	public void setNol(int nol) {
		this.nol = nol;
	}
	@Override
	public String toString() {
		return "TechEmp [eid=" + eid + ", ename=" + ename + ", obj=" + obj + ", bpay=" + bpay + ", nol=" + nol + "]";
	}
	public int calsal()
	{
		int sal;
		sal=(int) (bpay+(bpay*0.12));
		System.out.println(sal);
		return sal;
	}

}
