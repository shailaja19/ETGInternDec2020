package com.sonata.JavaBean;

public interface SalaryCalculation {
	public void salCal();

}
