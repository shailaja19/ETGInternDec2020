package com.sonata.JavaBean;

public class Employee {
	int empId;
	String empName;
	int empsal;
	
	Employee(int id,String name,int sal)
	{
		this.empId=id;
		this.empName=name;
		this.empsal=sal;
	}
	
	
	void display()
	{
		System.out.println(empId);
		System.out.println(empName);
		System.out.println(empsal);
	}

}