package com.sonata.JavaBean;

public class Manager extends Employee implements SalaryCalculation{

	Manager(int id, String name, int sal)
	{
		super(id, name, sal);
	}
		
		@Override
		public void salCal() {
		
		
		}

		// TODO Auto-generated constructor stub

	public static void main(String[] args)
	{
		Manager m=new Manager(1, "ABC", 200000);
		m.display();
		
		

	}
}
