package com.sonata.JavaBean;

public class Tester extends Employee implements SalaryCalculation{

	Tester(int id, String name, int sal) {
		super(id, name, sal);
		// TODO Auto-generated constructor stub
	}
	@Override
	public void salCal() {
		
	}
	public static void main(String[] args) {
	   Tester t=new Tester(3, "Reddy", 15000);
	   t.display();

	}	
}

