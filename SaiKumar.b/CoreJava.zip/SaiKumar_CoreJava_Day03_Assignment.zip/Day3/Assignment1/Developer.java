package com.sonata.JavaBean;

public class Developer extends Employee implements SalaryCalculation{

			Developer(int id, String name, int sal) {
				super(id, name, sal);
				// TODO Auto-generated constructor stub
			}

			@Override
			public void salCal() {
				// TODO Auto-generated method stub
				
			}
			

			public static void main(String args[])
			{
				Developer d=new Developer(2, "Kumar", 50000);
				d.display();
				
			}
}
