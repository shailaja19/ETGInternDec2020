package com.sonata;

public class TestShape {

	public static void main(String[] args) {
		 
		double a=5, b=3, c=4 ;
		Shape tri = new Triangle(a,b,c);
		System.out.println("Area of Triangle is " + tri.area());
		
		double width=3, length=2;
		Shape rect = new Rectangle(width,length);
		System.out.println("Area of Rectangle is " + rect.area());
		
		double length1=8;
		Shape squr = new Square(length1);
		System.out.println("Area of Square is " + squr.area());
				
	
	}

}
