package com.sonata;

public class OwnException extends Exception
{
	OwnException(String s)
	{
		super(s);
	}
}
