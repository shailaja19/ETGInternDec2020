package com.sonata;

public class CustomException {
		public static void main(String[] args) throws OwnException
		{
			int AnnualSalary = 20000;
			if (AnnualSalary<100000)
				throw new OwnException("Salary is less than 100k");
			else
				System.out.println("salary is more than 100k");
	}

}
