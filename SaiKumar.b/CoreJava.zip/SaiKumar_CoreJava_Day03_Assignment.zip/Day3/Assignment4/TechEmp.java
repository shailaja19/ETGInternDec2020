package com.sonata.day3;

public class TechEmp extends Emp  implements EmpInterface{
	@Override
	public double calculateSalary() {
		double HRA=  basicpay*0.12;
		return basicpay-HRA;
	}
	public static void main(String[] args) {
		TechEmp t1=new TechEmp();
		Address a1= new Address();
		
		 a1.setDoorno(1234);
		 a1.setCity("Hyderabad");
		 
		 a1.setStreet("Gachibowli");
		 System.out.println(a1);
		 t1.setEmpid(001);
		 t1.setEname("sai");
		 t1.setLeaves(15);
		 t1.setBasicpay(5200);
		 System.out.println(t1);
		 System.out.println("The salary of Empolyee");
		 t1.display();
		 }

}
