package com.sonata.day3;

public class Staff extends Emp implements EmpInterface {
	@Override
	public double calculateSalary() {
		double HRA= basicpay*0.18;
		return basicpay-HRA;
	}
	public static void main(String[] args) {
		Staff t1=new Staff();
		Address a1= new Address();
		
		 a1.setDoorno(1231);
		 a1.setCity("Chennai");
		 a1.setStreet("vada chennai");
		 System.out.println(a1);
		 t1.setEmpid(0001);
		 t1.setEname("sai kumar");
		 t1.setLeaves(12);
		 t1.setBasicpay(10000);
		 System.out.println(t1);
		 System.out.println("The salary of Staff Empolyee");
		 t1.display();
		 }
	
}
