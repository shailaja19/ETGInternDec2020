package com.sonata.day3;

public interface EmpInterface {
	public double calculateSalary();
}
