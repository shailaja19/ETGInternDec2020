package com.sonata;

public class Product {
	int pid;
	String pname;
    double proprice;
    Product (int id , String Name, int pp) {
    	this.pid = id;
    	this.pname= Name;
    	this.proprice = pp;
    }
    Product() {} 
    public double Tprice()
    {
    	int gst = 20;
    	return  proprice+gst;
    }
    public void display() 
    {
    	System.out.println(pid);
    	System.out.println(pname);
    	System.out.println(Tprice());
    }
}
