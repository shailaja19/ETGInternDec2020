package com.sonata;

public class ProductMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product s1= new Product( 1 , "Oven" , 469);
		Product s2= new Product( 2 , "Air Conditioner" , 479);
		s1.display();
		s2.display();
	}

}
