package com.sonata;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1= new Student( 469 , "Sai Kumar Reddy" , 10);
		Student s2= new Student( 470 , "Batman" , 11);
		s1.display();
		s2.display();
	}

}
