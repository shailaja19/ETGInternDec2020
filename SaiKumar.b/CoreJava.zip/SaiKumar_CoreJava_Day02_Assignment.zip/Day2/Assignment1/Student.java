package com.sonata;

public class Student {
	int stdid;	
	String stdname;
	int stdclass;	
	
	Student() {} 
	
	Student (int id , String Name, int c) 
	{
		this.stdid = id;
		this.stdname= Name;
		this.stdclass = c;
	}
	public void display() {
		System.out.println(stdid);
		System.out.println(stdname);
		System.out.println(stdclass);
	}
}	