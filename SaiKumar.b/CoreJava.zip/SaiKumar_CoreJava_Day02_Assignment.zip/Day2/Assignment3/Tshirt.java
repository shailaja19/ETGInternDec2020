package com.sonata;

public class Tshirt {
		String color;
		String material;
		String design;
		String size;
		Tshirt(String color1, String material1, String design1,String size1) //parameterized constructor or constructor with arguments
		{
			this.color = color1;
			this.material= material1;
			this.design= design1;
			this.size= size1;
		}
		Tshirt() { } //blank constructor 
		public void display() {
			System.out.println(color);
			System.out.println(material);
			System.out.println(design);
			System.out.println(size);
		}
}
