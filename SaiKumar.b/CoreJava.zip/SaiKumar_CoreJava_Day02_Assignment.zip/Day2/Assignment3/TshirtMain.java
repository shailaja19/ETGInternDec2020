package com.sonata;

public class TshirtMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tshirt s1= new Tshirt( "black","nylon","polka dots","S");
		Tshirt s2= new Tshirt( "white","cotton","kaddhar","XL");
		Tshirt s3= new Tshirt( "blue","silk","plain","L");

		s1.display();
		s2.display();
		s3.display();

	}

}
