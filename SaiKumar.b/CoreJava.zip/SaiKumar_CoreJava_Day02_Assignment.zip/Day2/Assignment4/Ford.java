package com.sonata;

public class Ford extends Car{
	int year;
	int manufacturerDiscount=2800;
	Ford(int a, double b , String c ){
	  	  super( a,b,c);
	  }
		double getSaleprice()
	    {
	   	 return regularPrice-manufacturerDiscount;
	    } 
		public static void main(String[] args) {
			Ford c1=new Ford( 100, 50000 , "BLACK" );
			c1.display();
		}
}
