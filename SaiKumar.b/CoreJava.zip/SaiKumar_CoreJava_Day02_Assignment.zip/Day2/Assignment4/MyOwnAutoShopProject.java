package com.sonata;

public class MyOwnAutoShopProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sedan s1=new Sedan( 100, 20000 , "BLACK",10);
		s1.display();
		
		Ford s2=new Ford( 100, 50000 , "BLACK" );
		s2.display();
		Ford s3=new Ford( 100, 23000 , "BLACK" );
		s3.display();
		
		Truck s4=new Truck( 100, 20000 , "BLACK",1000 );
		s4.display();
		
		Car s5=new Car( 100, 20000 , "BLACK");
		s5.display();

	}

}
