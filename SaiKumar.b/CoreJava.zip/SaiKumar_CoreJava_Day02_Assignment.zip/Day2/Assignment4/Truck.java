package com.sonata;

public class Truck extends Car {
	int weight;
	Truck(){}
	Truck(int a, double b , String c ,int d){
		super( a,b,c);
   	  	this.weight=d;
	}
	double getSalePrice()
	{
		if(weight >2000) {
			double discount=(regularPrice*0.1);
   		  	return regularPrice-discount;
   	  	}	
   	  	else {
   	  		double discount=(regularPrice*0.1);
   	  		return regularPrice-discount;
   	  	}
	}  
    public static void main(String[] args) {
    	Truck c1=new Truck( 60, 7000000 , "white",1500 );
    	c1.display();
    	
    	Truck c2=new Truck( 50, 50000 , "blue" ,3000);
    	c2.display();
	}

}
