package com.sonata;

public class Sedan extends Car{
	int length;
	Sedan(int a, double b , String c ,int d){
	super( a,b,c);
	this.length=d;
	}
	Sedan(){}
	double getSaleprice()
	{
		if(length >20) {
			double discount=regularPrice*0.05;
			return  regularPrice-discount;
		}
		else {
			double discount=regularPrice*0.1;
			return  regularPrice-discount;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Sedan c1=new Sedan( 250, 4200 , "Maroon",20);
	     c1.display();
   	     
	     Sedan c2=new Sedan( 150, 200000 , "Yellow" ,75);
	     c2.display();
	}
}
