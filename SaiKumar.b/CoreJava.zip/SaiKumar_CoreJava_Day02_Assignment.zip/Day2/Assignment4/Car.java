package com.sonata;

public class Car {
	int speed;
	double regularPrice;
	String color;
	double getSalePrice()
	{
		 return regularPrice;
	}
	Car(){}
	Car(int s, double p , String c){
		this.speed = s;
		this.regularPrice=p;
		this.color=c;
	}
	
	public void display() {
		System.out.println("The sales price of vehicle "+getSalePrice());
	}
}	