package com.sonata.assignment1;

public class JointAccount extends Bank implements BankInterface {
	public JointAccount( int a , String b,double c, double d) {
		super(a,b,c,d);
			}
	 
	@Override
	public double withDraw(double amount) {
		return amount;
	 	}
	@Override
	public double deposit(double amount) {
		return amount;
	 	}
	
	public double totalbalance(double amount1, double amount2) {
		return  amount1-amount2;
	 	}	
	public static void main(String[] args) {
		
		JointAccount s1 = new JointAccount(01 , "Sonata software" , 234000,34500);
		JointAccount s2 = new JointAccount(02 , " sonata" , 112000,61500);
		s1.display();
		s2.display();
			
	 }
	
	
}
