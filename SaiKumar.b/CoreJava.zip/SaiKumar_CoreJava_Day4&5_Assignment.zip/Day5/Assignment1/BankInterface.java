package com.sonata.assignment1;

public interface BankInterface {
	public double withDraw(double amount1);
	public double deposit(double amount2);
}
