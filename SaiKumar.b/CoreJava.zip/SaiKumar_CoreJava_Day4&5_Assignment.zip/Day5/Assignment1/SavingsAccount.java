package com.sonata.assignment1;

public class SavingsAccount {

	int accno;
	String accname;
	double balance;
	SavingsAccount(int a,String b,double c)
	{
		this.accno=a;
		this.accname=b;
		this.balance=c;
	}

}
