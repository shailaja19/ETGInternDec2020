package com.sonata.assignment1;

public class CurrentAccount extends Bank implements BankInterface {
	 public CurrentAccount( int a , String b,double c, double d) {
			super(a,b,c,d);
		}
	 
	 @Override
	 public double withDraw(double amount) {
	 	return amount;
	 }
	 @Override
	 public double deposit(double amount) {
	 	return amount;
	 }
	
	 public double totalbalance(double amount1, double amount2) {
	 	return  amount1-amount2;
	 }
	 public static void main(String[] args) {
			
			CurrentAccount s1 = new CurrentAccount(01 , "sai kumar" , 4000,3000);
			CurrentAccount s2 = new CurrentAccount(02 , "sai" , 43000,23000);

			s1.display();
			s2.display();
			
	 }
}
