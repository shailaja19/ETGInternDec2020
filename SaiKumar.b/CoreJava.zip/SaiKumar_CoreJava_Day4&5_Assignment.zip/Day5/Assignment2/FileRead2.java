package com.sonata.assignment2;

public class FileRead2 extends Thread{
	FileRead line; 
	  
    FileRead2(FileRead line) 
    { 
        this.line = line; 
    } 
  
    @Override
    public void run() 
    { 
        line.read(); 
    } 
}
