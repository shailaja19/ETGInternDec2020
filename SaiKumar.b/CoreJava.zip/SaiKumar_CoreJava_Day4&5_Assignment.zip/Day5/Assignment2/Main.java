package com.sonata.assignment2;

public class Main {
public static void main(String[] args) {
	FileRead obj = new FileRead();
	FileRead2 s1= new FileRead2(obj);
	FileRead2 s2= new FileRead2(obj);
	s1.start();
	s2.start();
}
}
