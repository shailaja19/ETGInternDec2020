package com.sonata.Assignment2;

import java.util.ArrayList;
import java.util.List;

public class StudentData {
	@SuppressWarnings("rawtypes")
	public static List<Student>getStudent(){
		 @SuppressWarnings("unchecked")
		List<Student> s=new ArrayList();
		 s.add(new Student( 1, "MEG",20));
		 s.add(new Student( 2 , "MEGHA",65));
		 s.add(new Student( 3 , "MEGHANA",32));
		 s.add(new Student( 4 , "MEGHANA GOWDA",88));
		 s.add(new Student( 5 , "MEGHANA M",98));
		 s.add(new Student( 6 , "MEGS",45));
		 s.add(new Student( 7 , "MEGS GOWDA",69));
		 return s;
	}
}
