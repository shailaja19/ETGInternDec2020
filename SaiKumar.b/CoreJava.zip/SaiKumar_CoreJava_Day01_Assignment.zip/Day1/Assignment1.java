package com.sonata;

public class Assignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=12,b=25,c=89;
		if(a>b && a>c)
			System.out.print(a+" is greater");
		else if(b>a && b>c)
			System.out.print(b+" is greater");
		else
			System.out.print(c+" is greater");
	}

}
