/*2) Write a program in java to display the first 10 natural numbers.
Expected output is 1 to 10 numbers*/
package com.sonata;

public class Assignment2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=10;i++)
			System.out.print(i+" ");
	}

}
