package com.sonata.Test;

import java.util.List;

import com.sonata.DaoImpl.StuDAOImpl;
import com.sonata.Model.Student;
import com.sonata.Model.Studetails;

public class TestBean {

	public static void main(String[] args) {
//		Studetails s1=new Studetails();
//		s1.setStuId(5);
//		s1.setStuName("e");
//		s1.setMarks(78.6);
//	StuDAOImpl dao=new StuDAOImpl();
//		int row=dao.addStudent(s1);
//		System.out.println(row);
//		List<Studetails> list =dao.getAllStudent();
//		for(Studetails se:list)
//		{
//			System.out.println(se.getStuId());
//			System.out.println(se.getStuName());
//			System.out.println(se.getMarks());
//		}
//		int d=dao.deleteStudent(s1);	
//		System.out.println(d);
//		StuDAOImpl dao=new StuDAOImpl();
//		List<Studetails> list=dao.getAllStudent();
//		list.stream().filter(i->Studetails.getMarks()>80).forEach(e->System.out.println(Studetails.getStuName()));
		StuDAOImpl dao=new StuDAOImpl();
		dao.getStudent();
	
	}

}
