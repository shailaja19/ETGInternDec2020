package com.sonata.Dao;

import java.util.List;

import com.sonata.Model.Studetails;

public interface StuDao {
	public int addStudent(Object object);
	public List<Studetails> getAllStudent();
	public int deleteStudent(Object object);
	public int updateStudent(Object object);
	public int getStudent(Object object);
}
