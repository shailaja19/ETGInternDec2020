package com.sonata.Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Studetails extends Student{

	public static void main(String[] args) {
		int stdId1=1;
		String stdName1="a";
		double Marks1=45;
		
		int stdId2=2;
		String stdName2="b";
		double Marks2=50;

		int stdId3=3;
		String stdName3="c";
		double Marks3=55;
		
		int stdId4=4;
		String stdName4="d";
		double Marks4=60;
		
		int stdId5=5;
		String stdName5="e";
		double Marks5=65;
		
		int stdId6=6;
		String stdName6="f";
		double Marks6=70;
		
		int stdId7=3;
		String stdName7="g";
		double Marks7=29;
		
		int stdId8=4;
		String stdName8="h";
		double Marks8=33;
		
		int stdId9=9;
		String stdName9="i";
		double Marks9=96;
		
		int stdId10=6;
		String stdName10="j";
		double Marks10=99;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/JDBCExample","root", "admin@123");
			PreparedStatement ps=con.prepareStatement("insert into Student values(?,?,?)");
			
			ps.setInt(1,stdId1);
			ps.setString(2,stdName1);
			ps.setDouble(3, Marks1);
			
			ps.addBatch();
			
			ps.setInt(1,stdId2);
			ps.setString(2,stdName2);
			ps.setDouble(3, Marks2);
		
			ps.addBatch();
			
			ps.setInt(1,stdId3);
			ps.setString(2,stdName3);
			ps.setDouble(3, Marks3);
			
			ps.addBatch();
			
			ps.setInt(1,stdId4);
			ps.setString(2,stdName4);
			ps.setDouble(3, Marks4);
			
			ps.addBatch();
			
			ps.setInt(1,stdId5);
			ps.setString(2,stdName5);
			ps.setDouble(3, Marks5);
		
			ps.addBatch();
			
			ps.setInt(1,stdId6);
			ps.setString(2,stdName6);
			ps.setDouble(3, Marks6);
			
			ps.addBatch();
			ps.setInt(1,stdId7);
			ps.setString(2,stdName7);
			ps.setDouble(3, Marks7);
			
			ps.addBatch();
			
			ps.setInt(1,stdId8);
			ps.setString(2,stdName8);
			ps.setDouble(3, Marks2);
		
			ps.addBatch();
			
			ps.setInt(1,stdId9);
			ps.setString(2,stdName9);
			ps.setDouble(3, Marks9);
			
			ps.addBatch();
			
			ps.setInt(1,stdId10);
			ps.setString(2,stdName10);
			ps.setDouble(3, Marks10);
			
			ps.executeBatch();
			
			System.out.println("records inserted successfully");
			
		}catch(ClassNotFoundException e1) { System.out.println(e1);}
		catch(SQLException e2) {e2.printStackTrace();}
	}
}

