package com.sonata.DaoImpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.sonata.Model.Studetails;

public class StuDAOImpl {
	int row=0;
	DbConn db=new DbConn();
	Studetails stu=null;
	
	//SAVE METHOD
	public int addStudent(Object object) {
		try {
			stu=(Studetails)object;
			PreparedStatement cs=db.getConnecetion().prepareStatement("insert into Student values(?,?,?)");
			cs.setInt(1, stu.getStuId());
			cs.setString(2, stu.getStuName());
			cs.setDouble(3,stu.getMarks());
			row=cs.executeUpdate();
			db.closeConnection();
		}catch(SQLException e) { System.out.println(e);}
		return row;
	}
	
	//UPDATE METHOD
	public int updateStudent(Object object)
	{
		try {
			stu=(Studetails)object;
			java.sql.PreparedStatement cs2=db.getConnecetion().prepareStatement("update Student set Marks=? where stdId=?");
			cs2.setDouble(1,12);
			cs2.setDouble(2,3);
			row=cs2.executeUpdate();
			
		}catch(SQLException se) {se.printStackTrace();}
		return row;
	}
	
	//DELETE METHOD
	public int deleteStudent(Object object)
	{
		try {
			stu=(Studetails)object;
			PreparedStatement cs1=db.getConnecetion().prepareStatement("delete from Student where stdId=?");
			cs1.setInt(1, 7);
			row=cs1.executeUpdate();
			
		}catch(SQLException se) {se.printStackTrace();}
		return row;
	}
	public List<Studetails> getAllStudent() {
		List<Studetails> stulist= new ArrayList<>();
		
		try {
			PreparedStatement cs1=(PreparedStatement) db.getConnecetion().prepareStatement("select * from Student");
			ResultSet rs=cs1.executeQuery();
			while(rs.next()) {
				Studetails s=new Studetails();
				int stuId=rs.getInt(1);
				//System.out.println(empId);
				String stuName=rs.getString(2);
				double Marks=rs.getDouble(3);
				stu.setStuId(stuId);
				stu.setStuName(stuName);
				stu.setMarks(Marks);
			}
		}catch(SQLException se ) {se.printStackTrace();}
		return stulist;			

	}
	public List<Studetails> getStudent() {
		List<Studetails> stulist= new ArrayList<>();
		
		try {
			PreparedStatement cs1=(PreparedStatement) db.getConnecetion().prepareStatement("select * from Student where Marks>80");
			ResultSet rs=cs1.executeQuery();
			
			while(rs.next()) {
				Studetails s=new Studetails();
				int stuId=rs.getInt(1);
				String stuName=rs.getString(2);
				double Marks=rs.getDouble(3);
				stu.setStuId(stuId);
				stu.setStuName(stuName);
				stu.setMarks(Marks);
				}
			
	
		}catch(SQLException se ) {se.printStackTrace();}
		return stulist;	

//
//				stulist.stream().filter(i->Studetails.getMarks()>80).forEach(e->System.out.println(Studetails.setStuName(s)));
				
				
		
//	public List<Studetails> getStudent(){
//
//		return flist.stream().filter(i->Student.getMarks>80).forEach(e->System.out.println(e.stuName()));
//	}
	}
}
