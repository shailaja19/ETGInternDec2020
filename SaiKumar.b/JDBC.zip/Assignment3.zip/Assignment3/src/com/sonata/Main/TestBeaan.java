package com.sonata.Main;
import daoimpl.ProdDaoImpl;
import com.sonata.Model.*;
public class TestBeaan {

	public static void main(String[] args) {
		Product p1=new Product();
		ProdDaoImpl dao=new ProdDaoImpl();
		int a=dao.delete(p1);
		int b=dao.update(p1);
		System.out.println(a);
		System.out.println(b);
	}

}
