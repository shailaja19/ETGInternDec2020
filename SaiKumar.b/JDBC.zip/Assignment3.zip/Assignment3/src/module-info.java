module com.sonata.promain1 {
	exports com.sonata.Main;
	requires com.sonata.prod1;
	//requires com.sonata.prod1;
}