module com.sonata.prod1 {
	exports daoimpl;
	exports com.sonata.Dao;
	exports com.sonata.Model;

	requires java.sql;
}