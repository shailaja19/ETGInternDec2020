package com.sonata.Dao;

public interface Productdao {
public int proinser(Object object);
public int update(Object object);
public int delete(Object object);
}
