package daoimpl;

import java.sql.CallableStatement;
import java.sql.SQLException;

import com.sonata.Dao.Productdao;
import com.sonata.Model.Product;

public class ProdDaoImpl implements Productdao {
int u=0,d=0;
DbConn db=new DbConn();
Product product=null;
@Override
public int proinser(Object object)
{
	return 0;
}
@Override
public int update(Object object) {
	// TODO Auto-generated method stub
	try {
		 CallableStatement cs=db.getConnection().prepareCall("{call proupd(?,?)}");
		 cs.setDouble(1, 5670);
		 cs.setInt(2, 4000);
		 u=cs.executeUpdate();
	}catch(SQLException e) {e.printStackTrace();}
	return u;
}
@Override
public int delete(Object object) {
	// TODO Auto-generated method stub
	try {
		 CallableStatement cs=db.getConnection().prepareCall("{call prodel(?)}");
		 cs.setInt(1,5);
		 d=cs.executeUpdate();
	}catch(SQLException e) {e.printStackTrace();}
	return d;
}
}
